
document.addEventListener("DOMContentLoaded",()=>{
 const path=location.pathname.split("/").pop()||"index.html";
 document.querySelectorAll("nav a").forEach(a=>{
   const href=a.getAttribute("href");
   if(href===path || (path==="index.html" && href==="./")) a.classList.add("active");
 });
 document.querySelectorAll("[data-year]").forEach(el=>el.textContent=new Date().getFullYear());
});
